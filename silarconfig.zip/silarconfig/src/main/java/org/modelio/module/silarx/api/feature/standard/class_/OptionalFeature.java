package org.modelio.module.silarx.api.feature.standard.class_;

public class OptionalFeature {

}
