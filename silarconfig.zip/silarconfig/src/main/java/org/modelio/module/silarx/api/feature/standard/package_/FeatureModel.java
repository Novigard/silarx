package org.modelio.module.silarx.api.feature.standard.package_;

import org.modelio.metamodel.uml.statik.Package;

public class FeatureModel {

	public static final String STEREOTYPE_NAME = null;

	public static Object instantiate(Package obj) {
		// TODO Auto-generated method stub
		return null;
	}

}
