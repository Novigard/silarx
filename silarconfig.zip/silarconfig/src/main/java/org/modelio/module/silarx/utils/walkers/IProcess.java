package org.modelio.module.silarx.utils.walkers;


public interface IProcess<T extends IWalkable> {
    void process(T element);

    default WalkingStrategy getWalkingStrategy() {
        return WalkingStrategy.DEPTH;
    }

}
