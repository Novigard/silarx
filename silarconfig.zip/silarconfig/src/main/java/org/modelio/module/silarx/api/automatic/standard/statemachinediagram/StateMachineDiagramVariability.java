package org.modelio.module.silarx.api.automatic.standard.statemachinediagram;

import org.modelio.metamodel.diagrams.StateMachineDiagram;

public class StateMachineDiagramVariability {

	public static final String STEREOTYPE_NAME = null;

	public static Object instantiate(StateMachineDiagram obj) {
		// TODO Auto-generated method stub
		return null;
	}

}
