package org.modelio.module.silarx.api.projectsetup.standard.package_;

import org.modelio.metamodel.uml.statik.Package;

public class Model150 {

	public static final String STEREOTYPE_NAME = null;

	public static Object instantiate(Package obj) {
		// TODO Auto-generated method stub
		return null;
	}

}
