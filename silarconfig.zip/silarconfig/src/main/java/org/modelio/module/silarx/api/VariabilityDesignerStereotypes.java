package org.modelio.module.silarx.api;

public class VariabilityDesignerStereotypes {

	public static final String CALCULATED_PARAMETER = null;
	public static final String AlTERNATIVE_STRUCTURAL = null;

}
