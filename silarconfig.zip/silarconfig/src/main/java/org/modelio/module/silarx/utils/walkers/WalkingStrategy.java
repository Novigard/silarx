package org.modelio.module.silarx.utils.walkers;


public enum WalkingStrategy {
    DEPTH,
    BREADTH,
    REVERSEDEPTH;
}
