package org.modelio.module.silarx.utils;

import java.util.List;

import org.eclipse.draw2d.geometry.Rectangle;
import org.modelio.api.modelio.diagram.IDiagramGraphic;
import org.modelio.api.modelio.diagram.IDiagramHandle;
import org.modelio.api.modelio.diagram.IDiagramLink.LinkRouterKind;
import org.modelio.api.modelio.diagram.ILinkPath;
import org.modelio.module.silarx.handlers.tools.AddAlternativeVariationTool;
import org.modelio.module.silarx.handlers.tools.AddCalculatedParameterVariationTool;
import org.modelio.module.silarx.handlers.tools.AddOptionalVariationTool;

public class DiagramToolsUtils {

	public static void constraintCreation(AddOptionalVariationTool addOptionalVariationTool,
			String calculatedParameter, IDiagramHandle diagramHandle, IDiagramGraphic lastNode,
			List<IDiagramGraphic> otherNodes, List<LinkRouterKind> routerKinds, List<ILinkPath> paths,
			Rectangle rectangle) {
		// TODO Auto-generated method stub
		
	}

	public static boolean acceptElement(AddOptionalVariationTool addOptionalVariationTool,
			IDiagramHandle diagramHandle, IDiagramGraphic targetNode) {
		// TODO Auto-generated method stub
		return false;
	}

	public static void constraintCreation(AddCalculatedParameterVariationTool addCalculatedParameterVariationTool,
			String calculatedParameter, IDiagramHandle diagramHandle, IDiagramGraphic lastNode,
			List<IDiagramGraphic> otherNodes, List<LinkRouterKind> routerKinds, List<ILinkPath> paths,
			Rectangle rectangle) {
		// TODO Auto-generated method stub
		
	}

	public static boolean acceptElement(AddCalculatedParameterVariationTool addCalculatedParameterVariationTool,
			IDiagramHandle diagramHandle, IDiagramGraphic targetNode) {
		// TODO Auto-generated method stub
		return false;
	}

	public static void constraintCreation(AddAlternativeVariationTool addAlternativeVariationTool,
			String alternativeStructural, IDiagramHandle diagramHandle, IDiagramGraphic lastNode,
			List<IDiagramGraphic> otherNodes, List<LinkRouterKind> routerKinds, List<ILinkPath> paths,
			Rectangle rectangle) {
		// TODO Auto-generated method stub
		
	}

	public static boolean acceptElement(AddAlternativeVariationTool addAlternativeVariationTool,
			IDiagramHandle diagramHandle, IDiagramGraphic targetNode) {
		// TODO Auto-generated method stub
		return false;
	}

}
