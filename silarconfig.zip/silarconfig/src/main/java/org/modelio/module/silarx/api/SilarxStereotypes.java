package org.modelio.module.silarx.api;

public class SilarxStereotypes {

	public static final String OPTIONAL_STRUCTURAL = null;
	public static final String ALTERNATIVE_PARAMETER = null;

}
