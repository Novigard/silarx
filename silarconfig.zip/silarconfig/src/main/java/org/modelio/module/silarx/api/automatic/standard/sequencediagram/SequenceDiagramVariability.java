package org.modelio.module.silarx.api.automatic.standard.sequencediagram;

public class SequenceDiagramVariability {

}
