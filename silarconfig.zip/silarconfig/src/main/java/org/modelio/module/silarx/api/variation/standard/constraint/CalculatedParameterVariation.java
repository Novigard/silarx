package org.modelio.module.silarx.api.variation.standard.constraint;

public class CalculatedParameterVariation {

}
