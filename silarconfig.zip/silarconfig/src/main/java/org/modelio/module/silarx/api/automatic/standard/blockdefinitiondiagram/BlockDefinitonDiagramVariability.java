package org.modelio.module.silarx.api.automatic.standard.blockdefinitiondiagram;

public class BlockDefinitonDiagramVariability {

}
