package org.modelio.module.silarx.api;

public interface SilarParameter {

}
