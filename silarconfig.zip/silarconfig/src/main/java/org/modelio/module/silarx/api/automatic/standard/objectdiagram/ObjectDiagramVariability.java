package org.modelio.module.silarx.api.automatic.standard.objectdiagram;

public class ObjectDiagramVariability {

}
