package org.modelio.module.silarx.api.automatic.standard.activitydiagram;

public class ActivityDiagramVariability {

}
