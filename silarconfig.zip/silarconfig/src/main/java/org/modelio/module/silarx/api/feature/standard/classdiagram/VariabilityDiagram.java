package org.modelio.module.silarx.api.feature.standard.classdiagram;

public class VariabilityDiagram {

}
