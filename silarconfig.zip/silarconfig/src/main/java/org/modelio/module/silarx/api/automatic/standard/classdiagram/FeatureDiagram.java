package org.modelio.module.silarx.api.automatic.standard.classdiagram;

import org.modelio.metamodel.diagrams.ClassDiagram;

public class FeatureDiagram {

	public static final String STEREOTYPE_NAME = null;

	public static Object instantiate(ClassDiagram obj) {
		// TODO Auto-generated method stub
		return null;
	}

}
