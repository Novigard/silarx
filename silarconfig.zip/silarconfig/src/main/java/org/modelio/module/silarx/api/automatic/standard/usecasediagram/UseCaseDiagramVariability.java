package org.modelio.module.silarx.api.automatic.standard.usecasediagram;

public class UseCaseDiagramVariability {

}
