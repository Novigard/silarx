package org.modelio.module.silarx.handlers.tools;

import java.util.List;

import org.eclipse.draw2d.geometry.Rectangle;
import org.modelio.api.modelio.diagram.IDiagramGraphic;
import org.modelio.api.modelio.diagram.IDiagramHandle;
import org.modelio.api.modelio.diagram.IDiagramLink.LinkRouterKind;
import org.modelio.api.modelio.diagram.ILinkPath;

public class DiagramToolsUtils {

	public static boolean acceptElement(AddAlternativeParameterVariationTool addAlternativeParameterVariationTool, IDiagramHandle diagramHandle,
			IDiagramGraphic targetNode) {
		// TODO Auto-generated method stub
		return false;
	}

	public static void constraintCreation(AddAlternativeParameterVariationTool addAlternativeParameterVariationTool,
			String alternativeParameter, IDiagramHandle diagramHandle, IDiagramGraphic lastNode,
			List<IDiagramGraphic> otherNodes, List<LinkRouterKind> routerKinds, List<ILinkPath> paths,
			Rectangle rectangle) {
		// TODO Auto-generated method stub
		
	}

}
