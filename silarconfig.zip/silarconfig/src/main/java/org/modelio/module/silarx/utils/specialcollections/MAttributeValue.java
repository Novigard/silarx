package org.modelio.module.silarx.utils.specialcollections;

public class MAttributeValue {

}
