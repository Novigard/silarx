package org.modelio.module.silarx.impl;

public class SilarxLogService {

}
