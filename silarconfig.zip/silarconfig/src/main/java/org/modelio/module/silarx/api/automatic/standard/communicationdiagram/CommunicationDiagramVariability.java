package org.modelio.module.silarx.api.automatic.standard.communicationdiagram;

public class CommunicationDiagramVariability {

}
