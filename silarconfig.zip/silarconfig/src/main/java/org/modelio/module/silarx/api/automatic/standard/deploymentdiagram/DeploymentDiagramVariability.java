package org.modelio.module.silarx.api.automatic.standard.deploymentdiagram;

public class DeploymentDiagramVariability {

}
