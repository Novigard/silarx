package org.modelio.module.silarx.api.feature.standard.class_;

import org.modelio.metamodel.uml.infrastructure.ModelTree;

public class MandatoryFeature {

	public static MandatoryFeature create() {
		// TODO Auto-generated method stub
		return null;
	}

	public ModelTree getElement() {
		// TODO Auto-generated method stub
		return null;
	}

}
