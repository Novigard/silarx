package org.modelio.module.silarx.api.feature.standard.umlmodelelement;

public class ModelElement {

}
