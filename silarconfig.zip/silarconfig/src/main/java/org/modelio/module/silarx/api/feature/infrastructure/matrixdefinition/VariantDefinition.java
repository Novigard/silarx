package org.modelio.module.silarx.api.feature.infrastructure.matrixdefinition;

public class VariantDefinition {

}
