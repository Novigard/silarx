package org.modelio.module.silarx.api;

public interface IsilarxPeerModule {
	public static final String MODULE_NAME = "SiLaRX";

}
